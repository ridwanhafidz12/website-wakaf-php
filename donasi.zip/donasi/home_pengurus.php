<?php
include 'db.php';

// Ambil data pemasukan dan pengeluaran
$pemasukan = $conn->query("SELECT p.*, pr.program_name FROM pemasukan p JOIN program pr ON p.program_id = pr.id");
$pengeluaran = $conn->query("SELECT p.*, pr.program_name FROM pengeluaran p JOIN program pr ON p.program_id = pr.id");

// Ambil data program untuk chart
$programsQuery = $conn->query("SELECT * FROM program");
$programData = [];

while ($program = $programsQuery->fetch_assoc()) {
    $program_id = $program['id'];
    $pemasukanProgram = $conn->query("SELECT SUM(jumlah) AS total FROM pemasukan WHERE program_id = $program_id")->fetch_assoc()['total'] ?? 0;
    $target_amount = $program['target_amount'];

    $programData[] = [
        'id' => $program_id,
        'name' => $program['program_name'],
        'target_amount' => $target_amount,
        'pemasukan' => $pemasukanProgram
    ];
}

function totalJumlah($result)
{
    $total = 0;
    while ($row = $result->fetch_assoc()) {
        $total += $row['jumlah'];
    }
    return $total;
}

$totalPemasukan = totalJumlah($conn->query("SELECT * FROM pemasukan"));
$totalPengeluaran = totalJumlah($conn->query("SELECT * FROM pengeluaran"));
$totalDonasi = $totalPemasukan - $totalPengeluaran;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Web Donasi Pengurus</title>
    <link rel="stylesheet" href="style.css">
    <script src="scripts.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.23/jspdf.plugin.autotable.min.js"></script>
    <style>
        .chart-container {
            width: 300px;
            height: 300px;
            margin: 10px;
            position: relative;
        }

        .chart-wrapper {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }

        .summary {
            text-align: center;
            margin-top: 10px;
        }

        @media (max-width: 768px) {
            .chart-container {
                width: 200px;
                height: 200px;
            }
        }

        @media (max-width: 480px) {
            .chart-container {
                width: 150px;
                height: 150px;
            }
        }

        .download-pdf {
            margin-top: 150px;
        }

        /* Custom styles for table */
        .belum-terealisasikan {
            background-color: #ffdddd;
        }

        .terealisasikan {
            background-color: #ddffdd;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div>
            <a href="home_pengurus.php">
                <img src="az1.png" width="60px" alt="Logo Azzakiyyah">
            </a>
        </div>
        <div>
            <div class="dropdown">
                <a href="#" class="dropbtn">Zakat</a>
                <div class="dropdown-content">
                    <a href="zakat_mal.php">Zakat Mal</a>
                    <a href="zakat_fitrah.php">Zakat Fitrah</a>
                </div>
            </div>
            <a href="#">Infaq</a>
            <a href="index.php">Sedekah</a>
            <a href="#">Wakaf</a>
            <div class="dropdown">
                <a href="#" class="dropbtn">Input Donasi</a>
                <div class="dropdown-content">
                    <a href="create_program.php" style>Buat Program</a>
                    <a href="input_pemasukan.php">Input Pemasukan</a>
                    <a href="input_pengeluaran.php">Input Pengeluaran</a>
                </div>
            </div>
        </div>
    </nav>
    <h1>Data Donasi Pengurus</h1>
    <input type="text" id="search" placeholder="Search">

    <h2>Pemasukan</h2>
    <div id="pemasukan-pagination">
        <table id="pemasukan-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Jumlah</th>
                    <th>Program</th>
                    <th>Bulan</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $pemasukan->fetch_assoc()) : ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td class="rupiah"><?= number_format($row['jumlah'], 0, ',', '.') ?></td>
                        <td><?= $row['program_name'] ?></td>
                        <td><?= $row['bulan'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div id="pemasukan-pagination-controls" class="pagination-controls"></div>
        <div class="summary">
            <p>Total Pemasukan: Rp.<?= number_format($totalPemasukan, 0, ',', '.') ?></p>
        </div>

        <h2>Pengeluaran</h2>
        <table id="pengeluaran-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Jumlah</th>
                    <th>Program</th>
                    <th>Keterangan</th>
                    <th>Bulan</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $pengeluaran->fetch_assoc()) : ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td class="rupiah"><?= number_format($row['jumlah'], 0, ',', '.') ?></td>
                        <td><?= $row['program_name'] ?></td>
                        <td class="keterangan"><?= $row['keterangan'] ?></td>
                        <td><?= $row['bulan'] ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div id="pengeluaran-pagination-controls" class="pagination-controls"></div>
    </div>

    <div class="summary">
        <p>Total Pengeluaran: Rp.<?= number_format($totalPengeluaran, 0, ',', '.') ?></p>
        <p>Saldo Donasi Saat Ini: Rp.<?= number_format($totalDonasi, 0, ',', '.') ?></p>
    </div>

    <?php if (count($programData) > 0): ?>
        <h2>Donasi Chart</h2>
        <div class="chart-wrapper">
            <?php foreach ($programData as $program): ?>
                <div class="chart-container">
                    <canvas id="donasiChart<?= $program['id'] ?>"></canvas>
                    <div class="summary">
                        <p>Donasi Masuk: Rp.<?= number_format($program['pemasukan'], 0, ',', '.') ?> (<?= round(($program['pemasukan'] / $program['target_amount']) * 100, 2) ?>%)</p>
                        <p>Donasi Kurang: Rp.<?= number_format($program['target_amount'] - $program['pemasukan'], 0, ',', '.') ?> (<?= round((1 - ($program['pemasukan'] / $program['target_amount'])) * 100, 2) ?>%)</p>
                    </div>
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const ctx = document.getElementById('donasiChart<?= $program['id'] ?>').getContext('2d');
                        new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: ['Donasi Masuk', 'Donasi Kurang'],
                                datasets: [{
                                    data: [<?= $program['pemasukan'] ?>, <?= $program['target_amount'] - $program['pemasukan'] ?>],
                                    backgroundColor: ['#00ff0d', '#ff0000'],
                                    hoverBackgroundColor: ['#00a708', '#a70000']
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                title: {
                                    display: true,
                                    text: 'Status Donasi - <?= $program['name'] ?>'
                                }
                            }
                        });
                    });
                </script>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No programs available to display charts.</p>
    <?php endif; ?>

    <h2 class="download-pdf">Download PDF</h2>
    <form id="pdf-download-form">
        <label>Bulan:</label>
        <select id="month" name="month">
            <option value="01">Januari</option>
            <option value="02">Februari</option>
            <option value="03">Maret</option>
            <option value="04">April</option>
            <option value="05">Mei</option>
            <option value="06">Juni</option>
            <option value="07">Juli</option>
            <option value="08">Agustus</option>
            <option value="09">September</option>
            <option value="10">Oktober</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
        </select>
        <button type="button" id="download-pdf">Download PDF</button>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            function formatTable() {
                document.querySelectorAll('#pengeluaran-table tbody tr').forEach(row => {
                    row.querySelectorAll('td.keterangan').forEach(cell => {
                        if (cell.innerText.toLowerCase().includes('belum terealisasikan')) {
                            cell.classList.add('belum-terealisasikan');
                            cell.classList.remove('disalurkan');
                        } else if (cell.innerText.toLowerCase().includes('terealisasikan')) {
                            cell.classList.add('terealisasikan');
                            cell.classList.remove('belum-terealisasikan');
                        }
                    });
                });
            }

            formatTable();

        });
    </script>
</body>

</html>
