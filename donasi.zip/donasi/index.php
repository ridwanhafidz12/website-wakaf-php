<?php
include 'db.php';

// Ambil data program dan hitung pemasukan serta jumlah donatur untuk setiap program
$programsQuery = $conn->query("SELECT p.*, COUNT(d.id) AS jumlah_donatur FROM program p LEFT JOIN pemasukan d ON p.id = d.program_id GROUP BY p.id");
$programData = [];
$completedPrograms = [];

while ($program = $programsQuery->fetch_assoc()) {
    $program_id = $program['id'];
    $pemasukanProgram = $conn->query("SELECT SUM(jumlah) AS total FROM pemasukan WHERE program_id = $program_id")->fetch_assoc()['total'] ?? 0;
    $target_amount = $program['target_amount'];
    $jumlah_donatur = $program['jumlah_donatur'];

    $programDetails = [
        'id' => $program_id,
        'name' => $program['program_name'],
        'image' => $program['image'],
        'description' => $program['description'],
        'target_amount' => $target_amount,
        'pemasukan' => $pemasukanProgram,
        'jumlah_donatur' => $jumlah_donatur,
    ];

    if ($pemasukanProgram >= $target_amount) {
        $completedPrograms[] = $programDetails;
    } else {
        $programData[] = $programDetails;
    }
}

function totalJumlah($result)
{
    $total = 0;
    while ($row = $result->fetch_assoc()) {
        $total += $row['jumlah'];
    }
    return $total;
}

$totalPemasukan = totalJumlah($conn->query("SELECT * FROM pemasukan"));
$totalDonasi = $totalPemasukan;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wakaf Pendidikan Azzakiyyah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        .hero {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
        }

        .hero-content {
            flex: 1;
        }

        .hero-image {
            flex: 1;
            text-align: right;
        }

        h1 {
            color: #0098b0;
            font-size: 2.5em;
        }

        .btn-hubungi {
            background-color: #0098b0;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .features {
            padding: 80px 0;
            background-color: #f5f5f5;
        }

        .features h2 {
            text-align: center;
            margin-bottom: 50px;
            font-size: 36px;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }

        .feature-item {
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .feature-item i {
            font-size: 48px;
            color: #1e88e5;
            margin-bottom: 20px;
        }

        .feature-item h3 {
            margin-bottom: 15px;
        }

        .stats {
            background-color: #fff;
            padding: 40px 0;
            text-align: center;
        }

        .stat {
            display: inline-block;
            margin: 0 20px;
        }

        .stat-value {
            font-size: 36px;
            font-weight: bold;
            color: #333;
        }

        .stat-label {
            font-size: 18px;
            color: #666;
        }

        .stat-button {
            background-color: #008000;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
        }

        .option {
            display: inline-block;
            margin: 0 20px;
            width: 150px;
            text-align: center;
        }

        .option img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }

        .option-label {
            font-size: 18px;
            color: #333;
        }

        .slider-section {
            height: 100vh;
            background: url('mekkah.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .slider-content {
            text-align: center;
            color: white;
            animation: fadeInDown 2s;
        }

        .slider-content h1 {
            font-size: 4em;
            text-transform: uppercase;
        }

        .ziswaf-section {
            padding: 50px 0;
            background: #f4f4f4;
            text-align: center;
        }

        .ziswaf-section h2 {
            margin-bottom: 30px;
        }

        .ziswaf-cards {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .ziswaf-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 22%;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            transition: transform 0.3s;
        }

        .ziswaf-card:hover {
            transform: translateY(-10px);
        }

        .campaign-section {
            padding: 50px 0;
            background: #e9ecef;
        }

        .campaign-section h2 {
            text-align: center;
            margin-bottom: 40px;
        }

        .campaign-slider {
            width: 80%;
            margin: 0 auto;
        }

        .campaign-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin: 0 10px;
        }

        .campaign-card img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .campaign-card h3 {
            margin-bottom: 15px;
        }

        .campaign-card p {
            font-size: 0.9em;
            color: #555;
        }

        /* Additional Styles for Campaign Cards */
        .card-wrapper {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
        }

        .card-container {
            width: 300px;
            height: 550px;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s, box-shadow 0.3s;
            background-color: #fff;
            text-align: center;
            margin: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .card-container img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-bottom: 1px solid #ddd;
        }

        .card-container h3 {
            margin: 10px 0;
            font-size: 1.2em;
            color: #333;
        }

        .card-container p {
            font-size: 14px;
            color: #555;
            padding: 0 10px;
            margin: 0;
        }

        .card-container .progress {
            height: 20px;
            margin-top: 10px;
        }

        .card-container .progress-bar {
            background-color: #2596be;
            color: #fff;
            text-align: center;
            line-height: 20px;
        }

        .card-container .btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 15px;
            background-color: #2596be;
            color: #fff;
            text-align: center;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .card-container .btn:hover {
            background-color: yellow;
            color: #2596be;
            transform: scale(1.05);
        }

        @media (max-width: 768px) {
            .card-container {
                width: 350px;
            }

            .card-wrapper {
                display: flex;
                overflow-x: scroll;
                scroll-snap-type: x mandatory;
                -webkit-overflow-scrolling: touch;
            }

            .card-container {
                scroll-snap-align: start;
                flex: 0 0 80%;
                margin-right: 10px;
            }
        }

        @media (max-width: 480px) {
            .card-container {
                width: 300px;
            }
        }

        .text-container {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
        }

        .contact-section {
            padding: 50px 0;
            background: #ffff;
            color: #575757;
        }

        .contact-section h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .contact-section .contact-info,
        .contact-section .maps {
            display: flex;
            justify-content: center;
            gap: 50px;
            margin-top: 30px;
        }

        .contact-info {
            max-width: 400px;
        }

        .maps iframe {
            width: 100%;
            height: 300px;
            border: none;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
            margin-bottom: 65px;
        }

        .bottom-navbar {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            background-color: #2596be;
            display: flex;
            justify-content: space-around;
            align-items: center;
            padding: 10px 0;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        .bottom-navbar .nav-link {
            color: white;
            text-align: center;
            font-size: 14px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .bottom-navbar .nav-link:hover {
            color: yellow;
        }

        .bottom-navbar .nav-link i {
            font-size: 24px;
            margin-bottom: 5px;
        }

        .bottom-navbar .nav-text {
            display: block;
            font-size: 12px;
        }

        @media (max-width: 768px) {
            .bottom-navbar .nav-link i {
                font-size: 20px;
            }

            .bottom-navbar .nav-text {
                font-size: 10px;
            }
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="az1.png" alt="Logo Wakaf Pendidikan" height="40">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="#">Panduan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Artikel</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Laporan</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Kategori</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Galang Dana</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="slider-section">
            <div class="slider-content animate__animated animate__fadeInDown">
                <h1>Wakaf Pendidikan Azzakiyyah</h1>
                <p>Membuka jalan pendidikan untuk generasi yang lebih baik</p>
            </div>
        </section>
        <section class="hero">
            <div class="hero-content">
                <h1>Tentang Wakaf Pendidikan</h1>
                <p>Wakaf Pendidikan adalah platform wakaf online untuk kemaslahatan umat yang bertujuan untuk memudahkan umat dalam berwakaf dan menyalurkan dana wakaf ke program-program yang bermanfaat.</p>
                <a href="#" class="btn-hubungi">Hubungi Kami</a>
            </div>
            <div class="hero-image">
                <img src="hero-image.png" alt="Ilustrasi Layanan Kesehatan Online">
            </div>
        </section>

        <section id="features" class="features">
            <div class="container">
                <h2>Fitur Unggulan</h2>
                <div class="feature-grid">
                    <div class="feature-item">
                        <i class="fas fa-mobile-alt"></i>
                        <h3>Mudah Diakses</h3>
                        <p>Berwakaf kapan saja dan di mana saja melalui perangkat mobile Anda</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-shield-alt"></i>
                        <h3>Aman & Terpercaya</h3>
                        <p>Transaksi wakaf Anda dijamin aman dan dikelola oleh lembaga terpercaya</p>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-chart-line"></i>
                        <h3>Transparan</h3>
                        <p>Laporan penggunaan dana wakaf yang transparan dan dapat diakses publik</p>
                    </div>
                </div>
            </div>
        </section>
        <section class="campaign-section">
            <h2 class="campaign-title"><b>Program Wakaf</b></h2>
            <div class="campaign-slider">
                <div class="card-wrapper">
                    <?php foreach ($programData as $program) :
                        $progress = round(($program['pemasukan'] / $program['target_amount']) * 100, 2); // Menghitung persentase progress
                    ?>
                        <div class="card-container">
                            <a href="donasi.php?id=<?= $program['id'] ?>" style="text-decoration: none; color: #b1b01d;">
                                <img src="<?= $program['image'] ?>" alt="<?= $program['name'] ?>">
                                <h3><b><?= $program['name'] ?></b></h3>
                                <p><?= $program['description'] ?></p>
                                <div class="text-container">
                                    <p><b>Jumlah Wakif:</b></p>
                                    <p><?= $program['jumlah_donatur'] ?></p>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" style="width: <?= $progress ?>%;" aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                                        <?= $progress ?>%
                                    </div>
                                </div>
                                <div class="text-container">
                                    <p>Target Kebutuhan:</p>
                                    <p>Rp. <?= number_format($program['target_amount'], 0, ',', '.') ?></p>
                                </div>
                                <div class="text-container">
                                    <p>Donasi Masuk:</p>
                                    <p>Rp. <?= number_format($program['pemasukan'], 0, ',', '.') ?></p>
                                </div>
                                <a href="donasi.php?id=<?= $program['id'] ?>" class="btn">Lihat Detail</a>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="ziswaf-section">
            <h2>Kategori ZISWAF</h2>
            <div class="ziswaf-cards">
                <div class="ziswaf-card animate__animated animate__fadeInUp">
                    <h3>Zakat</h3>
                    <p>Salurkan zakat Anda untuk membantu yang membutuhkan.</p>
                </div>
                <div class="ziswaf-card animate__animated animate__fadeInUp animate__delay-1s">
                    <h3>Infaq</h3>
                    <p>Bersedekah dengan infaq untuk kebaikan bersama.</p>
                </div>
                <div class="ziswaf-card animate__animated animate__fadeInUp animate__delay-2s">
                    <h3>Sedekah</h3>
                    <p>Berikan sedekah untuk meringankan beban sesama.</p>
                </div>
                <div class="ziswaf-card animate__animated animate__fadeInUp animate__delay-3s">
                    <h3>Wakaf</h3>
                    <p>Investasikan wakaf untuk masa depan yang lebih baik.</p>
                </div>
            </div>
        </section>
        <section class="contact-section">
            <h2>Kontak dan Lokasi</h2>
            <div class="contact-info">
                <div>
                    <h3>Alamat</h3>
                    <p>Gedogan Rt 05, Sumbermulyo, Bambanglipura, Bantul, DI Yogyakarta</p>
                </div>
                <div>
                    <h3>Whatsapp</h3>
                    <p>+62851-5938-0703</p>
                </div>
            </div>
            <div class="maps">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d659.3655358427122!2d110.31904366158176!3d-7.9234387099417605!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7aff69cc5481a5%3A0xdd726145fff4c37e!2sPESANTREN%20PUTRI%20JOGJA%20AZZAKIYYAH!5e0!3m2!1sid!2sid!4v1724473913647!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>


        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-tQpHlISxI2msZ71RPlmxd1/5CTpCJf+N8ZR9zIuW8Y4FwAxE1Uf/9N2xwVpHRkZx" crossorigin="anonymous"></script>

        <script>
            $(document).ready(function() {
                $('.card-wrapper').slick({
                    infinite: true,
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    dots: true,
                    autoplay: true,
                    autoplaySpeed: 3000,
                    responsive: [{
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2
                        }
                    }, {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1
                        }
                    }]
                });
            });
        </script>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Wakaf Pendidikan Azzakiyyah. All rights reserved.</p>
        </div>
    </footer>

    <div class="bottom-navbar">
        <a href="index.php" class="nav-link">
            <i class="bx bx-home"></i>
            <span class="nav-text">Home</span>
        </a>
        <a href="ziswaf.php" class="nav-link">
            <i class="bx bx-donate-heart"></i>
            <span class="nav-text">Ziswaf</span>
        </a>
        <a href="riwayat.php" class="nav-link">
            <i class="bx bx-history"></i>
            <span class="nav-text">Riwayat</span>
        </a>
        <a href="wakif.php" class="nav-link">
            <i class="bx bx-user"></i>
            <span class="nav-text">Wakif</span>
        </a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>